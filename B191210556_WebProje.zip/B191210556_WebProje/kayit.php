<?php
$adi=$_POST["adi"];
$soyadi=$_POST["soyadi"];
$email=$_POST["email"];
$telefonnumarasi=$_POST["telefon"];
$mesaj=$_POST["mesaj"];
echo "Adi: $adi <br>";
echo "Soyadi: $soyadi <br>";
echo "Email: $email <br>";
echo "Telefon Numarasi: $telefonnumarasi <br>";
echo "Mesaj: $mesaj <br>";
?>
